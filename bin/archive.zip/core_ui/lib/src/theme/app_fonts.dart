part of core_ui;

class AppFonts {
  static TextStyle normal13 = const TextStyle(
    fontWeight: FontWeight.w400,
    fontSize: 13,
  );
}
