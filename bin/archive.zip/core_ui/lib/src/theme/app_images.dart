part of core_ui;

class AppImages {
}
