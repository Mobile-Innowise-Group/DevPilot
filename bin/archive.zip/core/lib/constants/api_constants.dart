class ApiConstants {
  ///Endpoint path
  static const String login = '/login';

}
