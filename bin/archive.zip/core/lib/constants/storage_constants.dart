class StorageConstants {
  static const String authToken = 'authToken';
}
