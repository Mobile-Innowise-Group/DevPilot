library navigation;

export 'app_router/app_router.dart';
export 'di/navigation_di.dart';
