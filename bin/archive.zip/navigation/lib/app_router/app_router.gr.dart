part of 'app_router.dart';

class _$AppRouter{}